from flask import Flask, render_template, request
import firebase_admin
from firebase_admin import credentials, db
app = Flask(__name__)
config = {"apiKey": "AIzaSyDUACuhbFrhBrLYt-UfXuUvQfhxpse5yD8",
    "authDomain": "sparshselenium.firebaseapp.com",
    "databaseURL": "https://sparshselenium.firebaseio.com",
    "projectId": "sparshselenium",
    "storageBucket": "sparshselenium.appspot.com",
    "messagingSenderId": "997497475662",
    "appId": "1:997497475662:web:bb80bf5fdc11e9c024a91f",
    "measurementId": "G-WEX2HY2X7C",
    "serviceAccount": "static/service.json"}
cred = credentials.Certificate('static/service.json')
try:
    firebase_admin.initialize_app(cred, {'databaseURL': 'https://skytech-34bb4.firebaseio.com/'})
except ValueError:
    print("Already Called")
##############################################################
@app.route('/')
def index():
    ref = db.reference('/SkySchools')
    data = ref.get()
    school_name = []
    school_phone = []
    reg = []
    data = dict(data)
    for key, value in data.items():
        school_phone.append(value['Phone No'])
        reg.append(value['School_Reg_No'])
        school_name.append(value['Name_of_School'])
    print(school_name,school_phone)
    return render_template("index.html",sp=school_phone,sn=school_name,tot=len(data),rg=reg)


@app.route('/uploaded')
def uploaded():
    import xlrd
    loc = (r"C:\Users\cools\PycharmProjects\Sky_Techs\static\25199456.xlsx")
    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)
    sheet.cell_value(0, 0)
    school_id = "25199456"
    users_ref = db.reference('/Schools/'+school_id)
    for i in range(1,sheet.nrows):
        sname = sheet.cell_value(i, 0)
        fname = sheet.cell_value(i, 1)
        mname = sheet.cell_value(i, 2)
        phone = sheet.cell_value(i, 3)
        stuid = sheet.cell_value(i, 4)
        busno = sheet.cell_value(i, 5)
        email = sheet.cell_value(i, 6)
        users_ref.child(str(int(stuid))).set({
            'Student_Name': sname,
            'Fathers_Name': fname,
            'Mothers_Name': mname,
            'Phone_No': phone,
            'Student_Id': stuid,
            'Bus_Allotment': busno,
            'Email': email
        })
    return "Done"


@app.route('/loginhandler',methods=['GET','POST'])
def loginhandler():
    email_id = request.form["email"]
    password = request.form["password"]
    school_name = request.form["schoolname"]

    school_ref = db.reference('/SkySchools')
    school_data = school_ref.get(school_name)
    school_data = school_data[0]
    school_reg_no=""
    for key,value in school_data.items():
        if key == school_name:
            school_reg_no = value["School_Reg_No"]

    student_info = db.reference('/Schools')
    student_data = student_info.get(school_reg_no)
    student_data = student_data[0]
    print("School Data: ",student_data)
    student_id=""
    for key,value in student_data.items():
        for key2, value2 in value.items():
            if (value2["Email"] == email_id):
                student_id = value2["Student_Id"]
                break
    student_id = int(student_id)
    print("Student_Id :", student_id)
    parent_ref = db.reference('/SkyParents')
    parent_data = parent_ref.get(student_id)
    my_target = parent_data[0]
    for key,value in my_target.items():
        if (value["Email_Id"] == email_id and
            value["Password"] == password and
            student_id == int(value["Student_Id"])):
            print("Accept",value["Email_Id"], value["Password"], value["Student_Id"])
            return render_template("post.html")
        print("Not Accept", value["Email_Id"], value["Password"], value["Student_Id"])
    return render_template("login.html")

##############################################################
@app.route('/school')
def school():
    return render_template('registerschool.html')

@app.route('/parent')
def parent():
    return render_template('registerparent.html')

@app.route('/login/<regid>')
def login(regid):
    # email id and pass => regid => match three
    ref = db.reference('/SkySchools')
    data = ref.get()
    for key, value in data.items():
        if(value["School_Reg_No"]==regid):
            return render_template("login.html",school=value['Name_of_School'])
    return render_template("login.html")




def insert():
    try:
        firebase_admin.initialize_app(cred,{'databaseURL': 'https://skytech-34bb4.firebaseio.com/'})
    except ValueError:
        print("Already Called")
    users_ref = db.reference('/SkySchools')
    sname="St Mary School" #done
    pname="Renu Sharma" #done
    regno="25483265" #done
    email="bijnorschool@hotmail.com" #done
    phnno="01342255330" #done
    passw="University@96"
    city_="Hapur"
    state="Uttar Pradesh"
    distt="Hapur"
    pinno="245101"
    stret=" Chakkar road"
    address=stret+" "+city_+" Dist: "+distt+" "+state+" Pin: "+pinno
    users_ref.child(sname).set({
        'Name_of_School': sname,
        'Principal_Name': pname,
        'School_Reg_No': regno,
        'Email_Id': email,
        'Password': passw,
        'Address': address,
        'Phone No': phnno,
    })


if __name__ == '__main__':
    app.run()

# {{ url_for('static', filename='css/bootstrap.min.css') }}
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
driver = webdriver.Chrome(executable_path=r"C:\Users\cools\Desktop\chromedriver_win32\chromedriver.exe")
#browser.get("http://127.0.0.1:5000//")
from time import sleep

driver.get('http://ec2-54-81-242-53.compute-1.amazonaws.com/')
sleep(5)
driver.find_element_by_id('logemail').send_keys("amazonaniruddha123@gmail.com")
driver.find_element_by_id('logpsk').send_keys("University@99")
driver.find_element_by_name('login').click()
